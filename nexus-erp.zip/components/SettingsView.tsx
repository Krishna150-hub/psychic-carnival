import React from 'react';

interface SettingsViewProps {
  onClose: () => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({ onClose }) => {
  return (
    <div className="flex flex-col h-full items-center justify-center bg-tally-bg">
        <div className="w-80 border-2 border-tally-border bg-tally-panel shadow-xl">
           <div className="bg-tally-green text-white text-center py-1 font-bold border-b border-tally-border">
              Company Info.
           </div>
           
           <div className="flex">
              <div className="w-8 border-r border-tally-border bg-tally-bg"></div>
              <div className="flex-1 py-4 flex flex-col gap-1">
                 
                 <MenuItem label="Select Company" highlight="S" />
                 <MenuItem label="Login as Remote User" highlight="L" />
                 <MenuItem label="Create Company" highlight="C" />
                 <MenuItem label="Backup" highlight="B" />
                 <MenuItem label="Restore" highlight="R" />
                 <MenuItem label="Quit" highlight="Q" onClick={onClose} />

              </div>
              <div className="w-8 border-l border-tally-border bg-tally-bg"></div>
           </div>
        </div>
    </div>
  );
};

const MenuItem = ({ label, highlight, onClick }: { label: string, highlight: string, onClick?: () => void }) => {
  const parts = label.split(highlight);
  return (
    <div 
      onClick={onClick}
      className="cursor-pointer hover:bg-tally-selection hover:text-black px-4 py-0.5 text-sm font-semibold flex justify-center"
    >
        <span>
          {parts[0]}<span className="text-red-600 font-bold">{highlight}</span>{parts[1]}
        </span>
    </div>
  )
}

export default SettingsView;