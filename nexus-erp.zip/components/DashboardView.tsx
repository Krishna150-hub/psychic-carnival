import React from 'react';
import { ViewState } from '../types';

interface DashboardProps {
  onChangeView: (view: ViewState) => void;
}

const DashboardView: React.FC<DashboardProps> = ({ onChangeView }) => {
  return (
    <div className="flex h-full">
      {/* Left Info Panel */}
      <div className="w-1/2 p-1 flex flex-col gap-1">
         <div className="flex h-1/2 gap-1">
             <div className="w-1/2 border border-tally-border bg-white flex flex-col">
                <div className="bg-tally-lightGreen text-white text-center text-xs font-bold py-1">Current Period</div>
                <div className="flex-1 flex items-center justify-center font-bold text-sm text-[#005e46]">
                   01-04-2023 to 31-03-2024
                </div>
             </div>
             <div className="w-1/2 border border-tally-border bg-white flex flex-col">
                <div className="bg-tally-lightGreen text-white text-center text-xs font-bold py-1">Current Date</div>
                <div className="flex-1 flex items-center justify-center font-bold text-sm text-[#005e46]">
                   Monday, 01 Apr 2024
                </div>
             </div>
         </div>
         
         <div className="flex-1 border border-tally-border bg-white flex flex-col">
             <div className="bg-tally-lightGreen text-white flex justify-between px-2 py-1 text-xs font-bold">
                <span>List of Selected Companies</span>
             </div>
             <div className="p-2">
                <div className="flex justify-between font-bold text-sm">
                   <span>Name of Company</span>
                   <span>Date of Last Entry</span>
                </div>
                <div className="mt-2 flex justify-between font-bold text-sm text-black">
                   <span>Nexus Enterprise Ltd</span>
                   <span>01-Apr-2024</span>
                </div>
             </div>
         </div>
      </div>

      {/* Gateway of Tally Menu (Right Side) */}
      <div className="w-1/2 p-8 flex justify-center items-start bg-tally-bg">
        <div className="w-64 border-2 border-tally-border bg-tally-panel shadow-xl">
           <div className="bg-tally-green text-white text-center py-1 font-bold border-b border-tally-border">
              Gateway of Tally
           </div>
           
           <div className="flex">
              <div className="w-8 border-r border-tally-border bg-tally-bg"></div>
              <div className="flex-1 py-2">
                 
                 <div className="mb-2">
                    <div className="text-gray-500 text-xs text-center uppercase mb-1">Masters</div>
                    <MenuItem label="Accounts Info." highlight="A" />
                    <MenuItem label="Inventory Info." highlight="I" />
                 </div>

                 <div className="mb-2">
                    <div className="text-gray-500 text-xs text-center uppercase mb-1">Transactions</div>
                    <MenuItem label="Accounting Vouchers" highlight="V" onClick={() => onChangeView(ViewState.INVOICES)} />
                    <MenuItem label="Inventory Vouchers" highlight="T" />
                    <MenuItem label="Utilities" highlight="U" />
                 </div>

                 <div className="mb-2">
                    <div className="text-gray-500 text-xs text-center uppercase mb-1">Reports</div>
                    <MenuItem label="Balance Sheet" highlight="B" />
                    <MenuItem label="Profit & Loss A/c" highlight="P" />
                    <MenuItem label="Stock Summary" highlight="S" />
                    <MenuItem label="Ratio Analysis" highlight="R" />
                 </div>
                 
                 <div className="mt-4">
                    <MenuItem label="Display" highlight="D" />
                    <MenuItem label="Quit" highlight="Q" />
                 </div>

              </div>
              <div className="w-8 border-l border-tally-border bg-tally-bg"></div>
           </div>
        </div>
      </div>
    </div>
  );
};

const MenuItem = ({ label, highlight, onClick }: { label: string, highlight: string, onClick?: () => void }) => {
  const parts = label.split(highlight);
  return (
    <div 
      onClick={onClick}
      className="cursor-pointer hover:bg-tally-selection hover:text-black px-4 py-0.5 text-sm font-semibold flex justify-center"
    >
        <span>
          {parts[0]}<span className="text-red-600 font-bold">{highlight}</span>{parts[1]}
        </span>
    </div>
  )
}

export default DashboardView;