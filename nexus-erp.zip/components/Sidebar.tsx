import React from 'react';
import { ViewState } from '../types';

interface SidebarProps {
  currentView: ViewState;
  onChangeView: (view: ViewState) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  // Classic Tally Right Side Buttons
  const buttons = [
    { label: 'Select Cmp', key: 'F1', action: () => onChangeView(ViewState.SETTINGS), highlight: true },
    { label: 'Shut Cmp', key: 'F1', underline: true, action: () => {} },
    { label: 'Date', key: 'F2', action: () => {} },
    { label: 'Period', key: 'F2', underline: true, action: () => {} },
    { label: 'Company', key: 'F3', action: () => onChangeView(ViewState.SETTINGS) },
    { label: 'Cmp Info', key: 'F3', underline: true, action: () => onChangeView(ViewState.SETTINGS) },
    { label: 'Connect', key: 'F4', action: () => {} },
    { label: 'Disconnect', key: 'F4', underline: true, action: () => {} },
    { label: 'Features', key: 'F11', action: () => {} },
    { label: 'Configure', key: 'F12', action: () => {} },
  ];

  return (
    <div className="w-32 bg-[#2a2a2a] text-white flex flex-col border-l-2 border-gray-600">
      <div className="flex-1 overflow-y-auto">
        {buttons.map((btn, idx) => (
          <button
            key={idx}
            onClick={btn.action}
            className="w-full text-left px-2 py-2 border-b border-gray-600 hover:bg-gray-700 flex items-center group relative h-12"
          >
            <div className="flex gap-1 items-baseline">
              <span className={`font-bold text-sm ${btn.highlight ? 'text-white' : 'text-[#50c8c6]'}`}>
                 {btn.key}
                 {btn.underline && <div className="h-0.5 bg-white w-full -mt-0.5"></div>}
              </span>
              <span className="text-xs text-gray-300 ml-1 leading-tight">{btn.label}</span>
            </div>
            {/* Glossy overlay effect */}
            <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
          </button>
        ))}
      </div>
      <div className="h-16 bg-[#1a1a1a] border-t border-gray-600 flex items-center justify-center">
         <button 
           onClick={() => onChangeView(ViewState.DASHBOARD)}
           className="text-[#50c8c6] text-xs font-bold flex flex-col items-center hover:text-white"
         >
           <span>Q: Quit</span>
           <div className="h-0.5 bg-[#50c8c6] w-8"></div>
         </button>
      </div>
    </div>
  );
};

export default Sidebar;