import React from 'react';
import { MOCK_INVOICES } from '../constants';

interface InvoicesViewProps {
  onClose: () => void;
}

const InvoicesView: React.FC<InvoicesViewProps> = ({ onClose }) => {
  return (
    <div className="flex flex-col h-full bg-tally-bg">
      {/* Title Bar */}
      <div className="bg-tally-lightGreen text-white px-2 py-1 flex justify-between items-center text-sm font-bold border-b border-tally-border">
         <div className="flex gap-4">
             <span>Day Book</span>
         </div>
         <button onClick={onClose} className="hover:text-red-200">X</button>
      </div>

      <div className="flex-1 p-4 overflow-auto">
         <div className="border border-tally-border bg-white min-h-full font-mono text-sm">
            {/* Table Header */}
            <div className="flex bg-tally-bg border-b border-tally-border font-bold text-center py-1 italic text-tally-green">
               <div className="w-24 border-r border-tally-border">Date</div>
               <div className="flex-1 border-r border-tally-border">Particulars</div>
               <div className="w-32 border-r border-tally-border">Vch Type</div>
               <div className="w-24 border-r border-tally-border">Vch No.</div>
               <div className="w-32 border-r border-tally-border">Debit Amount</div>
               <div className="w-32">Credit Amount</div>
            </div>

            {/* Table Body */}
            {MOCK_INVOICES.map((inv, idx) => (
               <div key={idx} className="flex border-b border-gray-200 hover:bg-yellow-100 cursor-pointer text-gray-800">
                   <div className="w-24 border-r border-gray-200 p-1 text-center">{inv.date}</div>
                   <div className="flex-1 border-r border-gray-200 p-1 font-bold">{inv.client}</div>
                   <div className="w-32 border-r border-gray-200 p-1 italic text-center">Sales</div>
                   <div className="w-24 border-r border-gray-200 p-1 text-center">{inv.id.split('-')[2]}</div>
                   <div className="w-32 border-r border-gray-200 p-1 text-right">{inv.status === 'Paid' ? inv.amount.toFixed(2) : ''}</div>
                   <div className="w-32 p-1 text-right">{inv.status !== 'Paid' ? inv.amount.toFixed(2) : ''}</div>
               </div>
            ))}
            
            {/* Total Line */}
             <div className="flex border-t-2 border-gray-400 mt-4 font-bold bg-tally-bg">
                   <div className="w-24 border-r border-gray-300 p-1"></div>
                   <div className="flex-1 border-r border-gray-300 p-1 text-right pr-4">Total</div>
                   <div className="w-32 border-r border-gray-300 p-1"></div>
                   <div className="w-24 border-r border-gray-300 p-1"></div>
                   <div className="w-32 border-r border-gray-300 p-1 text-right">68,950.00</div>
                   <div className="w-32 p-1 text-right">25,400.50</div>
               </div>
         </div>
      </div>
    </div>
  );
};

export default InvoicesView;